package com.cognizant;

public class ForDemo {

	public static void main(String[] args) {
	
		int a;
		
		for(a=0;a<=10;a++)
		{
			System.out.println("Cognizant : "+a);
		}

	}

}
