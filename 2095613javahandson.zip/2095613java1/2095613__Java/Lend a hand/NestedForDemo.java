package com.cognizant;

public class NestedForDemo {

	public static void main(String[] args) {
		
		
		for(int a=0;a<3;a++)
		{
			
			for(int b=0;b<3;b++){
				System.out.println("Cognizant : a="+a+"\t b="+b);
			}
		}

	}

}
